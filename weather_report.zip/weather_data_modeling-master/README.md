# weather_data_modling
Display yearly weather data
developed using Flask, Angular, MySql, Peewee
steps to run
1. use :>pip install -r re.txt
2. install mysql 
  :>sudo apt-get update
  :>sudo apt-get install mysql-server
3. :>create database weather
4. :>python create_table.py

start server
:>python run.py

api to fetch parse and store data

:>curl "localhost:8888/storeAll"
