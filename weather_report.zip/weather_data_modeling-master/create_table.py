#!/usr/bin/python

from app import create_tables
create_tables()
